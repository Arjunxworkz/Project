package com.xworkz.wizard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WizardApplicationTests {

	@Test
	void contextLoads() {
	}

}
